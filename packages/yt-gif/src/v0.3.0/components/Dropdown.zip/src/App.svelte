<!--  Svelte port of React example: https://github.com/fireship-io/229-multi-level-dropdown -->
<script>
	import NavBar from './NavBar.svelte';
	import NavItem from './NavItem.svelte';
	import DropdownMenu from './DropdownMenu.svelte';
	import IconButton from './IconButton.svelte';
	
	import {mdiPlus, mdiMenuDown, mdiBell} from '@mdi/js'
</script>

<NavBar>
	<NavItem>
		<span slot="trigger">
			<IconButton path={mdiPlus} />
		</span>
	</NavItem>
	
	<NavItem>
		<span slot="trigger">
			<IconButton path={mdiBell} />
		</span>
	</NavItem>
	
	<NavItem>
		<span slot="trigger">
			<IconButton path={mdiMenuDown} />
		</span>
		<DropdownMenu></DropdownMenu>
	</NavItem>
</NavBar>

<style>
	:root {
		--bg: #242526;
		--bg-accent: #484a4d;
		--text-color: #dadce1;
		--nav-size: 60px;
		--border: 1px solid #474a4d;
		--border-radius: 8px;
		--speed: 200ms; 
	}

	:global(body) {
		margin: 0;
		padding: 0;
		background: #151616;
		font-family: Helvetica;
	}
</style>